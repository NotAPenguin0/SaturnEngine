resources/shaders/texture_v.glsl
resources/shaders/texture_f.glsl