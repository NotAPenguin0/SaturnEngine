resources/shaders/postprocessing/default_v.glsl
resources/shaders/postprocessing/grayscale_f.glsl