resources/shaders/default_v.glsl
resources/shaders/default_f.glsl