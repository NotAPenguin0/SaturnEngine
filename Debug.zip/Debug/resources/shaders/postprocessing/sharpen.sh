resources/shaders/postprocessing/default_v.glsl
resources/shaders/postprocessing/sharpen_f.glsl